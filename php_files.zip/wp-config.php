<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'nanodays');

/** MySQL database username */
define('DB_USER', 'nanodays');

/** MySQL database password */
define('DB_PASSWORD', 'nanodays');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Y^wGg5X.cjMFe,[./y*`~BPi/Jml!S/2&G5QrJRMt<yY|u/) lA>L M~ET8y)~Lx');
define('SECURE_AUTH_KEY',  'O7@_ ;D} wE%Qs-OQnTKkVBY;=VcH~xW-bwhU^|^whs`(=ORS2UDsEZ_=}x_Ux[~');
define('LOGGED_IN_KEY',    '{%&fTNP0h}|aJs5,v9O&y[o1|1IUvuA]E?.h2xZO:yoCh9N8>`jIV#QN/:0SLqtU');
define('NONCE_KEY',        ';Y!ON@}_$VU5fn?lqLOIh!iSR3++^q<@*$ZIudm;|G@ok%UJ9q50>^Hc,b54CqjV');
define('AUTH_SALT',        'x%&Bv r}eY#9G`<[ul_{lRL3A7@AApV?7|tR9*oe7)`{;PZ~[xLTs,9H]CTgrn5v');
define('SECURE_AUTH_SALT', '9Cy&9_vXN1PFo^!/.3pbj%hu^evK?}~<|T(Sj_(J4+@:2P4Ll;pH)Ht +l?Q)X1V');
define('LOGGED_IN_SALT',   '_c2=t#LXd1P8.vM.Oe0(@|=!e:3WMvam20fn*T&uvS7[RG#{AjUpE)4rzO&o[0nr');
define('NONCE_SALT',       '[~9K=m`:?D/GEtujN/Cl}/7Uq!9>A0y+r],Pr,Z/0vnvmN!$|cQk:xz?Vh|@@^.$');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
